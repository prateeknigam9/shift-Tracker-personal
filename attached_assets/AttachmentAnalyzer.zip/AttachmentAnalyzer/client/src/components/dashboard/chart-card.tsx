import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { format, parseISO } from "date-fns";
import {
  Bar,
  BarChart,
  ResponsiveContainer,
  XAxis,
  YAxis,
  Tooltip,
} from "recharts";

interface ChartCardProps {
  title: string;
  data: Array<{ period: string; hours?: number; pay?: number }>;
  dataKey: "hours" | "pay";
  loading?: boolean;
  valueFormatter: (value: number) => string;
  color: "primary" | "accent";
}

export default function ChartCard({
  title,
  data,
  dataKey,
  loading = false,
  valueFormatter,
  color,
}: ChartCardProps) {
  const formatPeriodLabel = (period: string) => {
    try {
      return format(parseISO(period), "MMM d");
    } catch (e) {
      return period;
    }
  };

  // Get color based on theme
  const getColor = () => {
    if (color === "primary") {
      return "var(--primary)";
    }
    if (color === "accent") {
      return "hsl(var(--accent))";
    }
    return "var(--primary)";
  };

  return (
    <Card>
      <CardContent className="p-4">
        <h2 className="text-lg font-medium mb-3">{title}</h2>

        {loading ? (
          <div className="space-y-2">
            <Skeleton className="h-[150px] w-full" />
          </div>
        ) : data.length === 0 ? (
          <div className="h-[150px] flex items-center justify-center text-muted-foreground">
            No data available
          </div>
        ) : (
          <div className="h-[150px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data}>
                <XAxis
                  dataKey="period"
                  tickFormatter={formatPeriodLabel}
                  tick={{ fontSize: 12 }}
                  tickLine={false}
                  axisLine={false}
                />
                <YAxis
                  hide
                  domain={[(dataMin: number) => 0, (dataMax: number) => dataMax * 1.2]}
                />
                <Tooltip
                  formatter={(value: number) => valueFormatter(value)}
                  labelFormatter={(label) => formatPeriodLabel(label)}
                  contentStyle={{
                    backgroundColor: "var(--popover)",
                    borderColor: "var(--border)",
                    borderRadius: "var(--radius)",
                    color: "var(--foreground)",
                  }}
                />
                <Bar
                  dataKey={dataKey}
                  radius={[4, 4, 0, 0]}
                  fill={getColor()}
                  maxBarSize={50}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

import { CalendarClock, Pencil, User, DollarSign } from "lucide-react";
import { Link } from "wouter";

interface BottomNavProps {
  currentTab: "shifts" | "pay" | "notes" | "profile";
}

export default function BottomNav({ currentTab }: BottomNavProps) {
  return (
    <nav className="md:hidden fixed bottom-0 inset-x-0 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 grid grid-cols-4 z-20">
      <Link href="/shifts">
        <a className={`flex flex-col items-center justify-center py-2 ${
          currentTab === "shifts" ? "text-primary" : ""
        }`}>
          <CalendarClock className="h-6 w-6" />
          <span className="text-xs mt-1">Shifts</span>
        </a>
      </Link>
      <Link href="/pay">
        <a className={`flex flex-col items-center justify-center py-2 ${
          currentTab === "pay" ? "text-primary" : ""
        }`}>
          <DollarSign className="h-6 w-6" />
          <span className="text-xs mt-1">Pay</span>
        </a>
      </Link>
      <Link href="/notes">
        <a className={`flex flex-col items-center justify-center py-2 ${
          currentTab === "notes" ? "text-primary" : ""
        }`}>
          <Pencil className="h-6 w-6" />
          <span className="text-xs mt-1">Notes</span>
        </a>
      </Link>
      <Link href="/profile">
        <a className={`flex flex-col items-center justify-center py-2 ${
          currentTab === "profile" ? "text-primary" : ""
        }`}>
          <User className="h-6 w-6" />
          <span className="text-xs mt-1">Profile</span>
        </a>
      </Link>
    </nav>
  );
}

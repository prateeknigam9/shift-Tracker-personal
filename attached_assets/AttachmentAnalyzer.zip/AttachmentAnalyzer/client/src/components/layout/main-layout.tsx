import { ReactNode, useState } from "react";
import { Moon, Settings, Sun } from "lucide-react";
import { Button } from "@/components/ui/button";
import BottomNav from "@/components/layout/bottom-nav";
import SettingsDialog from "@/components/settings/settings-dialog";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";

interface MainLayoutProps {
  children: ReactNode;
  currentTab: "shifts" | "pay" | "notes" | "profile";
}

export default function MainLayout({ children, currentTab }: MainLayoutProps) {
  const [darkMode, setDarkMode] = useState(
    localStorage.getItem("darkMode") === "true" ||
    window.matchMedia("(prefers-color-scheme: dark)").matches
  );
  const [showSettingsDialog, setShowSettingsDialog] = useState(false);
  const { user } = useAuth();

  const toggleDarkMode = () => {
    const newDarkMode = !darkMode;
    setDarkMode(newDarkMode);
    localStorage.setItem("darkMode", String(newDarkMode));
    
    if (newDarkMode) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  };

  return (
    <div className="max-w-lg mx-auto min-h-screen flex flex-col pb-16 md:pb-0 bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100">
      {/* Header */}
      <header className="sticky top-0 z-20 bg-white dark:bg-gray-800 shadow">
        <div className="flex justify-between items-center px-4 py-3">
          <div className="flex items-center">
            <h1 className="text-xl font-bold text-primary">ShiftTracker</h1>
          </div>
          <div className="flex items-center space-x-2">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={toggleDarkMode}
              className="rounded-full"
            >
              {darkMode ? (
                <Sun className="h-5 w-5" />
              ) : (
                <Moon className="h-5 w-5" />
              )}
              <span className="sr-only">Toggle dark mode</span>
            </Button>
            <Button 
              variant="ghost" 
              size="icon"
              onClick={() => setShowSettingsDialog(true)}
              className="rounded-full"
            >
              <Settings className="h-5 w-5" />
              <span className="sr-only">Settings</span>
            </Button>
          </div>
        </div>
        
        {/* Top Navigation (Desktop) */}
        <nav className="hidden md:flex border-b border-gray-200 dark:border-gray-700">
          <Link href="/shifts">
            <a className={`text-center flex-1 py-3 px-2 font-medium hover:bg-gray-100 dark:hover:bg-gray-700 ${
              currentTab === "shifts" ? "border-b-2 border-primary" : ""
            }`}>
              Shifts
            </a>
          </Link>
          <Link href="/pay">
            <a className={`text-center flex-1 py-3 px-2 font-medium hover:bg-gray-100 dark:hover:bg-gray-700 ${
              currentTab === "pay" ? "border-b-2 border-primary" : ""
            }`}>
              Pay
            </a>
          </Link>
          <Link href="/notes">
            <a className={`text-center flex-1 py-3 px-2 font-medium hover:bg-gray-100 dark:hover:bg-gray-700 ${
              currentTab === "notes" ? "border-b-2 border-primary" : ""
            }`}>
              Notes
            </a>
          </Link>
          <Link href="/profile">
            <a className={`text-center flex-1 py-3 px-2 font-medium hover:bg-gray-100 dark:hover:bg-gray-700 ${
              currentTab === "profile" ? "border-b-2 border-primary" : ""
            }`}>
              Profile
            </a>
          </Link>
        </nav>
      </header>

      {/* Main content */}
      <main className="flex-1 overflow-y-auto px-4 py-6">
        {children}
      </main>

      {/* Bottom Navigation (Mobile) */}
      <BottomNav currentTab={currentTab} />

      {/* Settings Dialog */}
      <SettingsDialog 
        open={showSettingsDialog} 
        onOpenChange={setShowSettingsDialog}
        darkMode={darkMode}
        onDarkModeChange={toggleDarkMode}
      />
    </div>
  );
}

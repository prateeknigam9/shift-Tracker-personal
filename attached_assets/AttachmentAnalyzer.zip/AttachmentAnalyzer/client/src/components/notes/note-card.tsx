import { Card, CardContent } from "@/components/ui/card";

interface NoteCardProps {
  date: string;
  title: string;
  content: string;
}

export default function NoteCard({ date, title, content }: NoteCardProps) {
  return (
    <Card>
      <CardContent className="p-3 bg-muted/40">
        <div className="flex justify-between items-start">
          <p className="text-sm font-medium">{date}</p>
          <span className="text-xs text-muted-foreground">{title}</span>
        </div>
        <p className="mt-1 text-sm whitespace-pre-wrap">{content}</p>
      </CardContent>
    </Card>
  );
}

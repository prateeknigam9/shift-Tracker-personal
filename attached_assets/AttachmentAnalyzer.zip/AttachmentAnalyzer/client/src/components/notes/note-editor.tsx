import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Sparkles } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function NoteEditor() {
  const [noteText, setNoteText] = useState("");
  const [processedText, setProcessedText] = useState("");
  const { toast } = useToast();

  const processNotesMutation = useMutation({
    mutationFn: async (notes: string) => {
      const response = await apiRequest("POST", "/api/notes/process", { notes });
      return response.json();
    },
    onSuccess: (data) => {
      setProcessedText(data.processed);
      toast({
        title: "Notes processed",
        description: "Your notes have been enhanced by AI",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to process notes",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleAIRewrite = () => {
    if (!noteText.trim()) {
      toast({
        title: "Empty notes",
        description: "Please write some notes to process",
        variant: "destructive",
      });
      return;
    }
    
    processNotesMutation.mutate(noteText);
  };

  const handleSaveNote = () => {
    const textToSave = processedText || noteText;
    
    if (!textToSave.trim()) {
      toast({
        title: "Empty notes",
        description: "Please write some notes to save",
        variant: "destructive",
      });
      return;
    }
    
    // In a real implementation, we would save this to a shift
    // For now, just show a toast message
    toast({
      title: "Note saved",
      description: "Your note has been saved successfully",
    });
    
    // Reset the form
    setNoteText("");
    setProcessedText("");
  };

  return (
    <Card>
      <CardContent className="p-4">
        <h2 className="text-lg font-medium mb-3">Work Notes</h2>
        
        <div className="space-y-4">
          <div>
            <label htmlFor="note-text" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              New Note
            </label>
            <Textarea
              id="note-text"
              rows={4}
              className="w-full resize-none"
              placeholder="Write your thoughts about your work day..."
              value={processedText || noteText}
              onChange={(e) => {
                setNoteText(e.target.value);
                // Clear processed text when user starts typing again
                if (processedText) {
                  setProcessedText("");
                }
              }}
            />
          </div>
          
          <div className="flex justify-between">
            <Button
              variant="outline"
              size="sm"
              className="gap-1"
              onClick={handleAIRewrite}
              disabled={!noteText.trim() || processNotesMutation.isPending}
            >
              {processNotesMutation.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Sparkles className="h-4 w-4" />
              )}
              AI Rewrite
            </Button>
            <Button
              size="sm"
              onClick={handleSaveNote}
              disabled={(!noteText.trim() && !processedText.trim()) || processNotesMutation.isPending}
            >
              Save Note
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

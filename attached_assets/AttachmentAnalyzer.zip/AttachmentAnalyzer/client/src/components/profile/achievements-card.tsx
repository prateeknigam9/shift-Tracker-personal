import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Achievement } from "@shared/schema";
import { Badge } from "@/components/ui/badge";

interface AchievementsCardProps {
  achievements: Achievement[];
  loading: boolean;
}

export default function AchievementsCard({ achievements, loading }: AchievementsCardProps) {
  return (
    <Card>
      <CardContent className="p-4">
        <h2 className="text-lg font-medium mb-3">Achievements</h2>
        
        {loading ? (
          <div className="space-y-3">
            {Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-16 w-full" />
            ))}
          </div>
        ) : achievements.length > 0 ? (
          <div className="space-y-3">
            {achievements.map((achievement) => (
              <div
                key={achievement.id}
                className={`p-3 rounded-lg flex items-center ${
                  achievement.unlocked
                    ? "bg-gray-100 dark:bg-gray-700"
                    : "bg-gray-50 dark:bg-gray-800 opacity-60"
                }`}
              >
                <div className="text-2xl mr-3">{achievement.icon}</div>
                <div>
                  <h3 className="font-medium">{achievement.title}</h3>
                  <p className="text-sm text-muted-foreground">
                    {achievement.description}
                  </p>
                </div>
                <div className="ml-auto">
                  {achievement.unlocked ? (
                    <Badge variant="outline" className="bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-100">
                      Unlocked
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-gray-300">
                      Locked
                    </Badge>
                  )}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="py-4 text-center text-muted-foreground">
            No achievements yet. Start tracking shifts to earn achievements!
          </div>
        )}
      </CardContent>
    </Card>
  );
}

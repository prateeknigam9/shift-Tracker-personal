import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { 
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Download, Upload } from "lucide-react";

interface SettingsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  darkMode: boolean;
  onDarkModeChange: () => void;
}

export default function SettingsDialog({ 
  open, 
  onOpenChange, 
  darkMode, 
  onDarkModeChange 
}: SettingsDialogProps) {
  const [defaultRate, setDefaultRate] = useState("15.00");
  const [defaultBreak, setDefaultBreak] = useState("0.5");
  const { toast } = useToast();

  const exportMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch("/api/backup/export", {
        credentials: "include",
      });
      
      if (!response.ok) {
        throw new Error(`Export failed: ${response.status}`);
      }
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "shifts.csv";
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    },
    onSuccess: () => {
      toast({
        title: "Export successful",
        description: "Your shifts have been exported",
      });
    },
    onError: (error) => {
      toast({
        title: "Export failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const importMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append("file", file);
      
      const response = await fetch("/api/backup/import", {
        method: "POST",
        body: formData,
        credentials: "include",
      });
      
      if (!response.ok) {
        throw new Error(`Import failed: ${response.status}`);
      }
      
      return await response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Import successful",
        description: `${data.imported} shifts have been imported`,
      });
    },
    onError: (error) => {
      toast({
        title: "Import failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleImportChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      importMutation.mutate(file);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Settings</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Theme Toggle */}
          <div className="flex items-center justify-between">
            <Label htmlFor="dark-mode" className="text-sm font-medium">Dark Mode</Label>
            <Switch
              id="dark-mode"
              checked={darkMode}
              onCheckedChange={onDarkModeChange}
            />
          </div>
          
          {/* Default Hourly Rate */}
          <div>
            <Label htmlFor="default-rate" className="text-sm font-medium">Default Hourly Rate ($)</Label>
            <Input
              id="default-rate"
              type="number"
              step="0.01"
              min="0"
              value={defaultRate}
              onChange={(e) => setDefaultRate(e.target.value)}
              className="mt-1"
            />
          </div>
          
          {/* Default Break Time */}
          <div>
            <Label htmlFor="default-break" className="text-sm font-medium">Default Break Time (hrs)</Label>
            <Input
              id="default-break"
              type="number"
              step="0.25"
              min="0"
              value={defaultBreak}
              onChange={(e) => setDefaultBreak(e.target.value)}
              className="mt-1"
            />
          </div>
          
          {/* Backup/Restore */}
          <div className="border-t pt-4 dark:border-gray-700">
            <h3 className="text-lg font-medium mb-2">Backup & Restore</h3>
            
            <div className="flex flex-col space-y-2">
              <Button 
                variant="outline" 
                onClick={() => exportMutation.mutate()}
                disabled={exportMutation.isPending}
                className="flex items-center gap-2"
              >
                {exportMutation.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Download className="h-4 w-4" />
                )}
                Export Shifts (CSV)
              </Button>
              
              <div className="relative">
                <input 
                  type="file" 
                  id="csvImport" 
                  accept=".csv"
                  onChange={handleImportChange}
                  className="hidden" 
                  disabled={importMutation.isPending}
                />
                <label 
                  htmlFor="csvImport" 
                  className={`block w-full bg-muted hover:bg-muted/80 text-center px-4 py-2 rounded-lg text-sm font-medium cursor-pointer flex items-center justify-center gap-2 ${
                    importMutation.isPending ? "opacity-70 cursor-not-allowed" : ""
                  }`}
                >
                  {importMutation.isPending ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Upload className="h-4 w-4" />
                  )}
                  Import Shifts (CSV)
                </label>
              </div>
            </div>
          </div>
        </div>
        
        <DialogFooter className="mt-6">
          <Button 
            onClick={() => onOpenChange(false)}
          >
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

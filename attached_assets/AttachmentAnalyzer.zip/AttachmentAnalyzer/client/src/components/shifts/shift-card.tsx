import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Shift } from "@shared/schema";
import { format, parseISO } from "date-fns";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";

interface ShiftCardProps {
  shift: Shift;
}

export default function ShiftCard({ shift }: ShiftCardProps) {
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const { toast } = useToast();

  const deleteShiftMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("DELETE", `/api/shifts/${shift.id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/shifts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/data"] });
      toast({
        title: "Shift deleted",
        description: "Your shift has been successfully deleted",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to delete shift",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const formatDate = (dateStr: string) => {
    return format(parseISO(dateStr), 'EEE, MMM d');
  };

  const formatTime = (timeStr: string) => {
    const date = new Date(`2000-01-01T${timeStr}`);
    return date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
  };

  const formatMoney = (amount: number) => {
    return `$${amount.toFixed(2)}`;
  };

  const handleDelete = () => {
    deleteShiftMutation.mutate();
    setShowDeleteDialog(false);
  };

  // Calculate hours
  const startTime = new Date(`2000-01-01T${shift.start_time}`);
  const endTime = new Date(`2000-01-01T${shift.end_time}`);
  let hours = (endTime.getTime() - startTime.getTime()) / (1000 * 60 * 60);
  hours = Math.max(0, hours - Number(shift.break_time));

  return (
    <>
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow overflow-hidden">
        <div className="p-4">
          <div className="flex justify-between items-start">
            <h3 className="font-medium">{formatDate(shift.date)}</h3>
            <span className="text-green-600 dark:text-green-400 font-bold">
              {formatMoney(Number(shift.total_pay))}
            </span>
          </div>
          <div className="mt-2 text-sm text-gray-600 dark:text-gray-400">
            <span>{formatTime(shift.start_time)} - {formatTime(shift.end_time)}</span>
            <span className="mx-2">•</span>
            <span>{hours.toFixed(1)} hrs</span>
            <span className="mx-2">•</span>
            <span>${Number(shift.hourly_rate)}/hr</span>
          </div>
          {shift.notes && (
            <div className="mt-2 text-sm">
              <p className="text-gray-700 dark:text-gray-300">{shift.notes}</p>
            </div>
          )}
          <div className="mt-3 flex justify-end">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => setShowDeleteDialog(true)}
              className="text-red-500 hover:text-red-700 hover:bg-red-100 dark:hover:bg-red-900/20 text-sm"
            >
              Delete
            </Button>
          </div>
        </div>
      </div>

      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Shift</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this shift? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDelete} 
              className="bg-red-500 hover:bg-red-600"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

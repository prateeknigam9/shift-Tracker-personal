import { useEffect } from "react";
import { useLocation } from "wouter";

export default function HomePage() {
  const [, navigate] = useLocation();

  useEffect(() => {
    // Redirect to shifts page as the default landing page
    navigate("/shifts");
  }, [navigate]);

  return null;
}

import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Shift } from "@shared/schema";
import MainLayout from "@/components/layout/main-layout";
import NoteEditor from "@/components/notes/note-editor";
import NoteCard from "@/components/notes/note-card";
import { Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { format, parseISO } from "date-fns";

export default function NotesPage() {
  const { toast } = useToast();

  // Fetch shifts that have notes
  const {
    data: shifts,
    isLoading,
    error,
  } = useQuery<Shift[]>({
    queryKey: ["/api/shifts"],
    select: (data) => data.filter(shift => shift.notes && shift.notes.trim() !== "")
  });

  if (error) {
    toast({
      title: "Error loading notes",
      description: "Please try again later",
      variant: "destructive",
    });
  }

  return (
    <MainLayout currentTab="notes">
      <div className="space-y-6">
        {/* Note Editor */}
        <NoteEditor />
        
        {/* Recent Notes */}
        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow">
          <h2 className="text-lg font-medium mb-3">Recent Notes</h2>
          
          {isLoading ? (
            <div className="flex justify-center py-6">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : shifts && shifts.length > 0 ? (
            <div className="space-y-3">
              {shifts.map(shift => (
                <NoteCard
                  key={shift.id}
                  date={format(parseISO(shift.date), 'MMM d, yyyy')}
                  title={getShiftTitle(shift)}
                  content={shift.notes || ""}
                />
              ))}
            </div>
          ) : (
            <div className="py-4 text-center text-muted-foreground">
              No notes found. Add notes to your shifts to see them here.
            </div>
          )}
        </div>
      </div>
    </MainLayout>
  );
}

// Helper function to generate a title for the note card based on shift data
function getShiftTitle(shift: Shift): string {
  const startTime = new Date(`2000-01-01T${shift.start_time}`);
  const endTime = new Date(`2000-01-01T${shift.end_time}`);
  
  const timeRange = `${startTime.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })} - ${endTime.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })}`;
  
  // Determine if it's a morning, afternoon, or evening shift
  const hour = startTime.getHours();
  let shiftType = 'Morning shift';
  if (hour >= 12 && hour < 17) {
    shiftType = 'Afternoon shift';
  } else if (hour >= 17) {
    shiftType = 'Evening shift';
  }
  
  return shiftType;
}

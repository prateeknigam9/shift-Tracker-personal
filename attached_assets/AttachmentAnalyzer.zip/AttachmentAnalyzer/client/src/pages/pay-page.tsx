import { useQuery } from "@tanstack/react-query";
import { Shift } from "@shared/schema";
import { format, addDays, startOfMonth, endOfMonth, parse } from "date-fns";
import MainLayout from "@/components/layout/main-layout";
import ChartCard from "@/components/dashboard/chart-card";
import { Card, CardContent } from "@/components/ui/card";
import { Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function PayPage() {
  const { toast } = useToast();

  // Fetch shifts
  const {
    data: shifts,
    isLoading: shiftsLoading,
    error: shiftsError,
  } = useQuery<Shift[]>({
    queryKey: ["/api/shifts"],
  });

  // Fetch dashboard data for pay chart
  const {
    data: dashboardData,
    isLoading: dashboardLoading,
    error: dashboardError,
  } = useQuery<{
    data: Array<{ period: string; hours: number; pay: number }>;
  }>({
    queryKey: ["/api/dashboard/data?period=weekly"],
  });

  if (shiftsError || dashboardError) {
    toast({
      title: "Error loading data",
      description: "Please try again later",
      variant: "destructive",
    });
  }

  // Calculate total hours, pay, and other stats
  const totalHours = shifts?.reduce((sum, shift) => {
    const startTime = new Date(`2000-01-01T${shift.start_time}`);
    const endTime = new Date(`2000-01-01T${shift.end_time}`);
    let hours = (endTime.getTime() - startTime.getTime()) / (1000 * 60 * 60);
    hours = Math.max(0, hours - Number(shift.break_time));
    return sum + hours;
  }, 0) || 0;

  const totalPay = shifts?.reduce((sum, shift) => sum + Number(shift.total_pay), 0) || 0;

  // Calculate next pay date (for demo purposes, assume it's the 15th or last day of the month)
  const today = new Date();
  let nextPayDate = new Date();
  
  if (today.getDate() < 15) {
    nextPayDate.setDate(15);
  } else if (today.getDate() >= 15 && today.getDate() < endOfMonth(today).getDate()) {
    nextPayDate = endOfMonth(today);
  } else {
    nextPayDate = new Date(today.getFullYear(), today.getMonth() + 1, 15);
  }

  // Generate pay schedule (this would normally come from the backend)
  const paySchedule = [];
  const currentMonth = today.getMonth();
  const currentYear = today.getFullYear();
  
  // Current month dates
  paySchedule.push({
    date: new Date(currentYear, currentMonth, 15),
    amount: totalPay / 2, // Simplified for demo
  });
  
  paySchedule.push({
    date: endOfMonth(new Date(currentYear, currentMonth)),
    amount: totalPay / 2, // Simplified for demo
  });
  
  // Next month dates
  paySchedule.push({
    date: new Date(currentYear, currentMonth + 1, 15),
    amount: 0, // Future pay
  });
  
  paySchedule.push({
    date: endOfMonth(new Date(currentYear, currentMonth + 1)),
    amount: 0, // Future pay
  });

  // Calculate average weekly values
  const weeksWorked = shifts && shifts.length > 0 ? Math.max(1, Math.ceil(totalHours / 40)) : 1;
  const avgHoursPerWeek = totalHours / weeksWorked;
  const avgPayPerWeek = totalPay / weeksWorked;

  const formatMoney = (amount: number) => {
    return `$${amount.toFixed(2)}`;
  };

  return (
    <MainLayout currentTab="pay">
      <div className="space-y-6">
        {/* Weekly Pay Chart */}
        <ChartCard
          title="Weekly Pay"
          data={dashboardData?.data || []}
          dataKey="pay"
          loading={dashboardLoading}
          valueFormatter={(value) => `$${value.toFixed(0)}`}
          color="accent"
        />

        {/* Next Pay Date */}
        <Card>
          <CardContent className="p-4">
            <h2 className="text-lg font-medium mb-3">Next Pay Date</h2>
            
            <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
              <div>
                <p className="text-sm text-muted-foreground">Estimated Pay</p>
                <p className="text-xl font-bold">
                  {shiftsLoading ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    formatMoney(totalPay)
                  )}
                </p>
              </div>
              <div className="text-right">
                <p className="text-sm text-muted-foreground">Date</p>
                <p className="font-medium">{format(nextPayDate, 'MMM d, yyyy')}</p>
              </div>
            </div>
            
            <div className="mt-4">
              <h3 className="text-sm font-medium text-muted-foreground mb-2">Pay Schedule</h3>
              <div className="grid grid-cols-2 gap-2">
                {paySchedule.map((pay, index) => (
                  <div key={index} className="p-2 bg-muted rounded text-sm">
                    <p className="font-medium">{format(pay.date, 'MMM d, yyyy')}</p>
                    <p className="text-muted-foreground">{formatMoney(pay.amount)}</p>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Year-to-Date Summary */}
        <Card>
          <CardContent className="p-4">
            <h2 className="text-lg font-medium mb-3">Year-to-Date Summary</h2>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-muted-foreground">Total Hours</p>
                <p className="text-xl font-bold">
                  {shiftsLoading ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    `${totalHours.toFixed(1)} hrs`
                  )}
                </p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Earnings</p>
                <p className="text-xl font-bold">
                  {shiftsLoading ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    formatMoney(totalPay)
                  )}
                </p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Avg Hours/Week</p>
                <p className="text-xl font-bold">
                  {shiftsLoading ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    `${avgHoursPerWeek.toFixed(1)} hrs`
                  )}
                </p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Avg Pay/Week</p>
                <p className="text-xl font-bold">
                  {shiftsLoading ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    formatMoney(avgPayPerWeek)
                  )}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}

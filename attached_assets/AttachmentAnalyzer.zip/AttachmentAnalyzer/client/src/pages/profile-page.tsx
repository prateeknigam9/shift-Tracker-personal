import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Shift, Achievement } from "@shared/schema";
import MainLayout from "@/components/layout/main-layout";
import ProfileCard from "@/components/profile/profile-card";
import AchievementsCard from "@/components/profile/achievements-card";
import EditProfileDialog from "@/components/profile/edit-profile-dialog";
import { Card, CardContent } from "@/components/ui/card";
import { Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { format, parseISO } from "date-fns";

export default function ProfilePage() {
  const [showEditProfileDialog, setShowEditProfileDialog] = useState(false);
  const { toast } = useToast();

  // Fetch achievements
  const {
    data: achievements,
    isLoading: achievementsLoading,
    error: achievementsError,
  } = useQuery<Achievement[]>({
    queryKey: ["/api/achievements"],
  });

  // Fetch shifts for stats
  const {
    data: shifts,
    isLoading: shiftsLoading,
    error: shiftsError,
  } = useQuery<Shift[]>({
    queryKey: ["/api/shifts"],
  });

  if (achievementsError || shiftsError) {
    toast({
      title: "Error loading profile data",
      description: "Please try again later",
      variant: "destructive",
    });
  }

  // Calculate stats
  const totalShifts = shifts?.length || 0;
  
  const avgShiftLength = shifts && shifts.length > 0
    ? shifts.reduce((sum, shift) => {
        const startTime = new Date(`2000-01-01T${shift.start_time}`);
        const endTime = new Date(`2000-01-01T${shift.end_time}`);
        let hours = (endTime.getTime() - startTime.getTime()) / (1000 * 60 * 60);
        hours = Math.max(0, hours - Number(shift.break_time));
        return sum + hours;
      }, 0) / shifts.length
    : 0;
  
  const avgHourlyRate = shifts && shifts.length > 0
    ? shifts.reduce((sum, shift) => sum + Number(shift.hourly_rate), 0) / shifts.length
    : 0;
  
  const firstShiftDate = shifts && shifts.length > 0
    ? shifts.reduce((earliest, shift) => {
        const shiftDate = parseISO(shift.date);
        return shiftDate < earliest ? shiftDate : earliest;
      }, parseISO(shifts[0].date))
    : null;

  return (
    <MainLayout currentTab="profile">
      <div className="space-y-6">
        {/* User Profile */}
        <ProfileCard onEditProfile={() => setShowEditProfileDialog(true)} />
        
        {/* Achievements */}
        <AchievementsCard 
          achievements={achievements || []} 
          loading={achievementsLoading} 
        />
        
        {/* Stats Summary */}
        <Card>
          <CardContent className="p-4">
            <h2 className="text-lg font-medium mb-3">Stats Summary</h2>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-muted-foreground">Total Shifts</p>
                <p className="text-xl font-bold">
                  {shiftsLoading ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    totalShifts
                  )}
                </p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Avg Shift Length</p>
                <p className="text-xl font-bold">
                  {shiftsLoading ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    `${avgShiftLength.toFixed(1)} hrs`
                  )}
                </p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Avg Hourly Rate</p>
                <p className="text-xl font-bold">
                  {shiftsLoading ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    `$${avgHourlyRate.toFixed(2)}`
                  )}
                </p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">First Shift</p>
                <p className="text-xl font-bold">
                  {shiftsLoading ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : firstShiftDate ? (
                    format(firstShiftDate, 'MMM d')
                  ) : (
                    'N/A'
                  )}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <EditProfileDialog
        open={showEditProfileDialog}
        onOpenChange={setShowEditProfileDialog}
      />
    </MainLayout>
  );
}

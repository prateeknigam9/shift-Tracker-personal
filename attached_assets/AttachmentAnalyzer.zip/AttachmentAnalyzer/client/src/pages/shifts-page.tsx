import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Shift } from "@shared/schema";
import MainLayout from "@/components/layout/main-layout";
import StatsCard from "@/components/dashboard/stats-card";
import ChartCard from "@/components/dashboard/chart-card";
import ShiftCard from "@/components/shifts/shift-card";
import AddShiftDialog from "@/components/shifts/add-shift-dialog";
import { Button } from "@/components/ui/button";
import { Loader2, Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function ShiftsPage() {
  const [showAddShiftDialog, setShowAddShiftDialog] = useState(false);
  const { toast } = useToast();

  // Fetch shifts
  const {
    data: shifts,
    isLoading: shiftsLoading,
    error: shiftsError,
  } = useQuery<Shift[]>({
    queryKey: ["/api/shifts"],
  });

  // Fetch dashboard data
  const {
    data: dashboardData,
    isLoading: dashboardLoading,
    error: dashboardError,
  } = useQuery<{
    data: Array<{ period: string; hours: number; pay: number }>;
  }>({
    queryKey: ["/api/dashboard/data?period=weekly"],
  });

  // Fetch AI insights
  const {
    data: aiInsights,
    isLoading: insightsLoading,
    error: insightsError,
  } = useQuery<{ summary: string }>({
    queryKey: ["/api/dashboard/summary"],
  });

  // Calculate total hours and pay
  const totalHours = shifts?.reduce((sum, shift) => {
    const startTime = new Date(`2000-01-01T${shift.start_time}`);
    const endTime = new Date(`2000-01-01T${shift.end_time}`);
    let hours = (endTime.getTime() - startTime.getTime()) / (1000 * 60 * 60);
    hours = Math.max(0, hours - Number(shift.break_time));
    return sum + hours;
  }, 0) || 0;

  const totalPay = shifts?.reduce((sum, shift) => sum + Number(shift.total_pay), 0) || 0;

  if (shiftsError || dashboardError || insightsError) {
    toast({
      title: "Error loading data",
      description: "Please try again later",
      variant: "destructive",
    });
  }

  return (
    <MainLayout currentTab="shifts">
      <div className="space-y-6">
        {/* Dashboard Stats */}
        <div className="grid grid-cols-2 gap-4">
          <StatsCard
            title="Total Hours"
            value={`${totalHours.toFixed(1)} hrs`}
            loading={shiftsLoading}
          />
          <StatsCard
            title="Total Pay"
            value={`$${totalPay.toFixed(2)}`}
            loading={shiftsLoading}
          />
        </div>

        {/* Charts */}
        <ChartCard
          title="Weekly Hours"
          data={dashboardData?.data || []}
          dataKey="hours"
          loading={dashboardLoading}
          valueFormatter={(value) => `${value.toFixed(1)}h`}
          color="primary"
        />

        {/* AI Insights */}
        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow">
          <h2 className="text-lg font-medium mb-3">AI Insights</h2>
          {insightsLoading ? (
            <div className="flex justify-center py-4">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : (
            <p className="text-sm text-gray-700 dark:text-gray-300">
              {aiInsights?.summary ||
                "No insights available yet. Add some shifts to get started!"}
            </p>
          )}
        </div>

        {/* Shifts List */}
        <div>
          <div className="flex justify-between items-center mb-3">
            <h2 className="text-lg font-medium">Recent Shifts</h2>
            <Button 
              size="sm" 
              onClick={() => setShowAddShiftDialog(true)}
              className="gap-1"
            >
              <Plus className="h-4 w-4" />
              Add Shift
            </Button>
          </div>

          {shiftsLoading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : shifts && shifts.length > 0 ? (
            <div className="space-y-3">
              {shifts.map((shift) => (
                <ShiftCard key={shift.id} shift={shift} />
              ))}
            </div>
          ) : (
            <div className="bg-muted/50 rounded-lg p-8 text-center">
              <p className="text-muted-foreground">No shifts recorded yet.</p>
              <Button 
                variant="outline" 
                className="mt-4"
                onClick={() => setShowAddShiftDialog(true)}
              >
                Add Your First Shift
              </Button>
            </div>
          )}
        </div>
      </div>

      <AddShiftDialog 
        open={showAddShiftDialog} 
        onOpenChange={setShowAddShiftDialog} 
      />
    </MainLayout>
  );
}

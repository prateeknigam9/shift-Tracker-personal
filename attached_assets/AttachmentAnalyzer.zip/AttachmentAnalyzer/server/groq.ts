import { Shift } from "@shared/schema";

// Simulated Groq API integration since we don't have the actual API client
// In a real implementation, we would use the groq-sdk package

export async function generateInsights(shifts: Shift[]): Promise<string> {
  if (!shifts.length) {
    return "No shifts recorded yet. Once you track some shifts, AI will provide personalized insights about your work patterns.";
  }

  // Calculate basic stats that would be used for analysis
  const totalShifts = shifts.length;
  let totalHours = 0;
  let totalPay = 0;
  
  const dayFrequency: Record<string, number> = {};
  const timeFrequency: Record<string, number> = {};
  
  shifts.forEach(shift => {
    // Calculate hours
    const startTime = new Date(`2000-01-01T${shift.start_time}`);
    const endTime = new Date(`2000-01-01T${shift.end_time}`);
    let hours = (endTime.getTime() - startTime.getTime()) / (1000 * 60 * 60);
    hours = Math.max(0, hours - Number(shift.break_time));
    
    totalHours += hours;
    totalPay += Number(shift.total_pay);
    
    // Track day frequency
    const date = new Date(shift.date);
    const day = date.toLocaleString('en-US', { weekday: 'long' });
    dayFrequency[day] = (dayFrequency[day] || 0) + 1;
    
    // Track shift timing (morning/afternoon/evening)
    const hour = startTime.getHours();
    let timeOfDay = 'morning';
    if (hour >= 12 && hour < 17) {
      timeOfDay = 'afternoon';
    } else if (hour >= 17) {
      timeOfDay = 'evening';
    }
    timeFrequency[timeOfDay] = (timeFrequency[timeOfDay] || 0) + 1;
  });
  
  // Find the most common day
  let mostCommonDay = '';
  let maxDayCount = 0;
  for (const day in dayFrequency) {
    if (dayFrequency[day] > maxDayCount) {
      mostCommonDay = day;
      maxDayCount = dayFrequency[day];
    }
  }
  
  // Find the most common time of day
  let mostCommonTime = '';
  let maxTimeCount = 0;
  for (const time in timeFrequency) {
    if (timeFrequency[time] > maxTimeCount) {
      mostCommonTime = time;
      maxTimeCount = timeFrequency[time];
    }
  }
  
  const avgHoursPerShift = totalHours / totalShifts;
  const avgPayPerShift = totalPay / totalShifts;
  
  // Generate an insight message based on the data
  // This would normally be done by the Groq API
  
  return `
    Based on your ${totalShifts} recorded shifts, you're averaging ${avgHoursPerShift.toFixed(1)} hours per shift with an average pay of $${avgPayPerShift.toFixed(2)}.
    
    Your most productive day appears to be ${mostCommonDay}, which makes up ${Math.round((maxDayCount / totalShifts) * 100)}% of your shifts. You tend to work more frequently during the ${mostCommonTime}, which might align well with your personal productivity rhythm.
    
    If you're looking to maximize earnings, consider scheduling more shifts on ${mostCommonDay} when you're consistently showing up for work.
  `;
}

export async function processNotes(notes: string): Promise<string> {
  // This would normally call the Groq API to process the notes
  // For now, we'll just return a slightly enhanced version of the input
  
  if (!notes.trim()) {
    return "Please provide some notes to process.";
  }
  
  // Simple enhancement - make it more professional
  let processed = notes;
  
  // Add a professional opening if not present
  if (!processed.match(/^(during|throughout|in|at) (today'?s?|this|the|my) (shift|workday|work day)/i)) {
    processed = `During today's shift, ${processed.charAt(0).toLowerCase() + processed.slice(1)}`;
  }
  
  // Format in a more structured way
  processed = processed.trim();
  if (!processed.endsWith('.')) {
    processed += '.';
  }
  
  // Add a reflective closing
  processed += " Looking forward to applying these insights in future shifts.";
  
  return processed;
}

import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { generateInsights, processNotes } from "./groq";
import { insertShiftSchema } from "@shared/schema";
import fs from "fs";
import csvParser from "csv-parser";
import multer from "multer";
import { stringify } from "csv-stringify/sync";

// Middleware to verify user is authenticated
const isAuthenticated = (req: Request, res: Response, next: Function) => {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Unauthorized" });
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth routes
  setupAuth(app);

  // File upload setup
  const upload = multer({ storage: multer.memoryStorage() });

  // Shift routes
  app.get("/api/shifts", isAuthenticated, async (req, res) => {
    try {
      const shifts = await storage.getShiftsByUserId(req.user!.id);
      res.json(shifts);
    } catch (error) {
      res.status(500).json({ message: "Failed to get shifts" });
    }
  });

  app.post("/api/shifts", isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertShiftSchema.parse(req.body);
      
      // Calculate total pay
      const startTime = new Date(`2000-01-01T${validatedData.start_time}`);
      const endTime = new Date(`2000-01-01T${validatedData.end_time}`);
      let hours = (endTime.getTime() - startTime.getTime()) / (1000 * 60 * 60);
      hours = Math.max(0, hours - Number(validatedData.break_time));
      const totalPay = hours * Number(validatedData.hourly_rate);
      
      const shift = await storage.createShift({
        ...validatedData,
        user_id: req.user!.id,
        total_pay: totalPay.toString(),
      });
      
      // Check for achievements
      await checkForAchievements(req.user!.id);
      
      res.status(201).json(shift);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.put("/api/shifts/:id", isAuthenticated, async (req, res) => {
    try {
      const shiftId = parseInt(req.params.id);
      const shift = await storage.getShiftById(shiftId);
      
      if (!shift) {
        return res.status(404).json({ message: "Shift not found" });
      }
      
      if (shift.user_id !== req.user!.id) {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      const validatedData = insertShiftSchema.parse(req.body);
      
      // Calculate total pay
      const startTime = new Date(`2000-01-01T${validatedData.start_time}`);
      const endTime = new Date(`2000-01-01T${validatedData.end_time}`);
      let hours = (endTime.getTime() - startTime.getTime()) / (1000 * 60 * 60);
      hours = Math.max(0, hours - Number(validatedData.break_time));
      const totalPay = hours * Number(validatedData.hourly_rate);
      
      const updatedShift = await storage.updateShift(shiftId, {
        ...validatedData,
        total_pay: totalPay.toString(),
      });
      
      res.json(updatedShift);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.delete("/api/shifts/:id", isAuthenticated, async (req, res) => {
    try {
      const shiftId = parseInt(req.params.id);
      const shift = await storage.getShiftById(shiftId);
      
      if (!shift) {
        return res.status(404).json({ message: "Shift not found" });
      }
      
      if (shift.user_id !== req.user!.id) {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      await storage.deleteShift(shiftId);
      res.sendStatus(204);
    } catch (error) {
      res.status(500).json({ message: "Failed to delete shift" });
    }
  });

  // Pay calculation routes
  app.get("/api/pay/daily", isAuthenticated, async (req, res) => {
    try {
      const date = req.query.date as string;
      if (!date) {
        return res.status(400).json({ message: "Date is required" });
      }
      
      const pay = await storage.getDailyPay(req.user!.id, date);
      res.json({ date, pay });
    } catch (error) {
      res.status(500).json({ message: "Failed to get daily pay" });
    }
  });

  app.get("/api/pay/weekly", isAuthenticated, async (req, res) => {
    try {
      const weekStart = req.query.week_start as string;
      if (!weekStart) {
        return res.status(400).json({ message: "Week start date is required" });
      }
      
      const pay = await storage.getWeeklyPay(req.user!.id, weekStart);
      res.json({ weekStart, pay });
    } catch (error) {
      res.status(500).json({ message: "Failed to get weekly pay" });
    }
  });

  // Dashboard data routes
  app.get("/api/dashboard/data", isAuthenticated, async (req, res) => {
    try {
      const period = req.query.period as string || 'weekly';
      const data = await storage.getDashboardData(req.user!.id, period);
      res.json(data);
    } catch (error) {
      res.status(500).json({ message: "Failed to get dashboard data" });
    }
  });

  app.get("/api/dashboard/summary", isAuthenticated, async (req, res) => {
    try {
      const shifts = await storage.getShiftsByUserId(req.user!.id);
      const insights = await generateInsights(shifts);
      res.json({ summary: insights });
    } catch (error) {
      res.status(500).json({ message: "Failed to generate summary" });
    }
  });

  // Profile routes
  app.get("/api/profile", isAuthenticated, async (req, res) => {
    try {
      const user = await storage.getUser(req.user!.id);
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Failed to get profile" });
    }
  });

  app.put("/api/profile", isAuthenticated, async (req, res) => {
    try {
      const { full_name } = req.body;
      if (!full_name) {
        return res.status(400).json({ message: "Full name is required" });
      }
      
      const updatedUser = await storage.updateUser(req.user!.id, { full_name });
      res.json(updatedUser);
    } catch (error) {
      res.status(500).json({ message: "Failed to update profile" });
    }
  });

  app.put("/api/password", isAuthenticated, async (req, res) => {
    try {
      const { currentPassword, newPassword } = req.body;
      if (!currentPassword || !newPassword) {
        return res.status(400).json({ message: "Current and new password are required" });
      }
      
      // This would typically verify the current password and hash the new one
      // For this example, we'll assume that's handled elsewhere
      
      res.sendStatus(200);
    } catch (error) {
      res.status(500).json({ message: "Failed to update password" });
    }
  });

  // Backup routes
  app.get("/api/backup/export", isAuthenticated, async (req, res) => {
    try {
      const shifts = await storage.getShiftsByUserId(req.user!.id);
      const shiftFields = ['id', 'date', 'start_time', 'end_time', 'break_time', 'hourly_rate', 'notes', 'total_pay'];
      const csvData = stringify(shifts, {
        header: true
      });
      
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', 'attachment; filename=shifts.csv');
      res.send(csvData);
    } catch (error) {
      res.status(500).json({ message: "Failed to export shifts" });
    }
  });

  app.post("/api/backup/import", isAuthenticated, upload.single('file'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }
      
      const results: any[] = [];
      
      // Parse CSV
      const parser = csvParser();
      
      parser.on('readable', () => {
        let record;
        while ((record = parser.read())) {
          results.push(record);
        }
      });
      
      parser.on('error', (err) => {
        throw new Error(`CSV parsing error: ${err.message}`);
      });
      
      parser.on('end', async () => {
        // Process the imported shifts
        const importedShifts = [];
        
        for (const row of results) {
          // Validate and import each shift
          try {
            const shift = await storage.createShift({
              ...row,
              user_id: req.user!.id
            });
            importedShifts.push(shift);
          } catch (e) {
            console.error("Failed to import shift:", e);
          }
        }
        
        res.json({ imported: importedShifts.length });
      });
      
      // Start the parsing process
      parser.write(req.file.buffer.toString());
      parser.end();
      
    } catch (error: any) {
      res.status(500).json({ message: `Failed to import shifts: ${error.message}` });
    }
  });

  // AI routes
  app.post("/api/notes/process", isAuthenticated, async (req, res) => {
    try {
      const { notes } = req.body;
      if (!notes) {
        return res.status(400).json({ message: "Notes are required" });
      }
      
      const processedNotes = await processNotes(notes);
      res.json({ processed: processedNotes });
    } catch (error) {
      res.status(500).json({ message: "Failed to process notes" });
    }
  });

  // Achievement routes
  app.get("/api/achievements", isAuthenticated, async (req, res) => {
    try {
      const achievements = await storage.getAchievementsByUserId(req.user!.id);
      res.json(achievements);
    } catch (error) {
      res.status(500).json({ message: "Failed to get achievements" });
    }
  });

  // Function to check for achievements
  async function checkForAchievements(userId: number) {
    try {
      const shifts = await storage.getShiftsByUserId(userId);
      const achievements = await storage.getAchievementsByUserId(userId);
      
      // Calculate total hours worked
      const totalHours = shifts.reduce((sum, shift) => {
        const startTime = new Date(`2000-01-01T${shift.start_time}`);
        const endTime = new Date(`2000-01-01T${shift.end_time}`);
        let hours = (endTime.getTime() - startTime.getTime()) / (1000 * 60 * 60);
        hours = Math.max(0, hours - Number(shift.break_time));
        return sum + hours;
      }, 0);
      
      // Check for "First Shift" achievement
      if (shifts.length === 1) {
        const existingAchievement = achievements.find(a => a.title === "First Shift");
        if (!existingAchievement) {
          await storage.createAchievement({
            user_id: userId,
            title: "First Shift",
            description: "Completed your first shift",
            icon: "🏆",
            unlocked: 1,
            unlocked_at: new Date()
          });
        }
      }
      
      // Check for "10 Hours Club" achievement
      if (totalHours >= 10) {
        const existingAchievement = achievements.find(a => a.title === "10 Hours Club");
        if (!existingAchievement) {
          await storage.createAchievement({
            user_id: userId,
            title: "10 Hours Club",
            description: "Worked more than 10 hours",
            icon: "⏰",
            unlocked: 1,
            unlocked_at: new Date()
          });
        }
      }
      
      // Additional achievements can be added here
      
    } catch (error) {
      console.error("Error checking achievements:", error);
    }
  }

  const httpServer = createServer(app);
  return httpServer;
}

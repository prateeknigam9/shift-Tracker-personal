import { users, shifts, achievements, type User, type InsertUser, type Shift, type Achievement } from "@shared/schema";
import { addDays, startOfWeek, endOfWeek, format, parseISO, subMonths } from 'date-fns';
import createMemoryStore from "memorystore";
import session from "express-session";
import { db } from "./db";
import { eq } from "drizzle-orm";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

const MemoryStore = createMemoryStore(session);
const PostgresSessionStore = connectPg(session);

// Define the storage interface
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, data: Partial<User>): Promise<User>;
  
  // Shift methods
  getShiftsByUserId(userId: number): Promise<Shift[]>;
  getShiftById(id: number): Promise<Shift | undefined>;
  createShift(shift: Partial<Shift>): Promise<Shift>;
  updateShift(id: number, data: Partial<Shift>): Promise<Shift>;
  deleteShift(id: number): Promise<void>;
  
  // Pay calculation methods
  getDailyPay(userId: number, date: string): Promise<number>;
  getWeeklyPay(userId: number, weekStart: string): Promise<number>;
  
  // Dashboard data methods
  getDashboardData(userId: number, period: string): Promise<any>;
  
  // Achievement methods
  getAchievementsByUserId(userId: number): Promise<Achievement[]>;
  createAchievement(achievement: Partial<Achievement>): Promise<Achievement>;
  
  // Session store
  sessionStore: any; // Using any for session store type
}

export class DatabaseStorage implements IStorage {
  sessionStore: any;
  
  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool, 
      createTableIfMissing: true 
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    
    // Create default achievements for new user
    await this.createDefaultAchievements(user.id);
    
    return user;
  }

  async updateUser(id: number, data: Partial<User>): Promise<User> {
    const [updatedUser] = await db.update(users)
      .set(data)
      .where(eq(users.id, id))
      .returning();
    
    if (!updatedUser) {
      throw new Error("User not found");
    }
    
    return updatedUser;
  }

  // Shift methods
  async getShiftsByUserId(userId: number): Promise<Shift[]> {
    return db.select().from(shifts)
      .where(eq(shifts.user_id, userId));
  }

  async getShiftById(id: number): Promise<Shift | undefined> {
    const [shift] = await db.select().from(shifts).where(eq(shifts.id, id));
    return shift;
  }

  async createShift(shiftData: Partial<Shift>): Promise<Shift> {
    const [shift] = await db.insert(shifts).values({
      user_id: shiftData.user_id!,
      date: shiftData.date!,
      start_time: shiftData.start_time!,
      end_time: shiftData.end_time!,
      break_time: shiftData.break_time!,
      notes: shiftData.notes || "",
      hourly_rate: shiftData.hourly_rate!,
      total_pay: shiftData.total_pay!,
    }).returning();
    
    return shift;
  }

  async updateShift(id: number, data: Partial<Shift>): Promise<Shift> {
    const [updatedShift] = await db.update(shifts)
      .set(data)
      .where(eq(shifts.id, id))
      .returning();
    
    if (!updatedShift) {
      throw new Error("Shift not found");
    }
    
    return updatedShift;
  }

  async deleteShift(id: number): Promise<void> {
    await db.delete(shifts).where(eq(shifts.id, id));
  }

  // Pay calculation methods
  async getDailyPay(userId: number, date: string): Promise<number> {
    const userShifts = await db.select()
      .from(shifts)
      .where(eq(shifts.user_id, userId));
    
    // Filter by date
    const dailyShifts = userShifts.filter(shift => shift.date === date);
    
    return dailyShifts.reduce((total: number, shift: any) => total + Number(shift.total_pay), 0);
  }

  async getWeeklyPay(userId: number, weekStartStr: string): Promise<number> {
    const weekStart = parseISO(weekStartStr);
    const weekEnd = addDays(weekStart, 6);
    
    const userShifts = await db.select().from(shifts).where(eq(shifts.user_id, userId));
    
    const weeklyShifts = userShifts.filter(shift => {
      const shiftDate = parseISO(shift.date);
      return shiftDate >= weekStart && shiftDate <= weekEnd;
    });
    
    return weeklyShifts.reduce((total: number, shift: any) => total + Number(shift.total_pay), 0);
  }

  // Dashboard data methods
  async getDashboardData(userId: number, period: string): Promise<any> {
    const userShifts = await db.select()
      .from(shifts)
      .where(eq(shifts.user_id, userId));
    
    if (userShifts.length === 0) {
      return { data: [] };
    }
    
    if (period === 'weekly') {
      // Group shifts by week
      const weeklyData: Record<string, { hours: number, pay: number }> = {};
      
      userShifts.forEach(shift => {
        const shiftDate = parseISO(shift.date);
        const weekStart = startOfWeek(shiftDate, { weekStartsOn: 1 });
        const weekKey = format(weekStart, 'yyyy-MM-dd');
        
        if (!weeklyData[weekKey]) {
          weeklyData[weekKey] = { hours: 0, pay: 0 };
        }
        
        // Calculate hours
        const startTime = new Date(`2000-01-01T${shift.start_time}`);
        const endTime = new Date(`2000-01-01T${shift.end_time}`);
        let hours = (endTime.getTime() - startTime.getTime()) / (1000 * 60 * 60);
        hours = Math.max(0, hours - Number(shift.break_time));
        
        weeklyData[weekKey].hours += hours;
        weeklyData[weekKey].pay += Number(shift.total_pay);
      });
      
      return {
        data: Object.keys(weeklyData).map(week => ({
          period: week,
          hours: weeklyData[week].hours,
          pay: weeklyData[week].pay
        })).slice(-4) // Last 4 weeks
      };
    } else if (period === 'monthly') {
      // Group shifts by month
      const monthlyData: Record<string, { hours: number, pay: number }> = {};
      
      userShifts.forEach(shift => {
        const shiftDate = parseISO(shift.date);
        const monthKey = format(shiftDate, 'yyyy-MM');
        
        if (!monthlyData[monthKey]) {
          monthlyData[monthKey] = { hours: 0, pay: 0 };
        }
        
        // Calculate hours
        const startTime = new Date(`2000-01-01T${shift.start_time}`);
        const endTime = new Date(`2000-01-01T${shift.end_time}`);
        let hours = (endTime.getTime() - startTime.getTime()) / (1000 * 60 * 60);
        hours = Math.max(0, hours - Number(shift.break_time));
        
        monthlyData[monthKey].hours += hours;
        monthlyData[monthKey].pay += Number(shift.total_pay);
      });
      
      return {
        data: Object.keys(monthlyData).map(month => ({
          period: month,
          hours: monthlyData[month].hours,
          pay: monthlyData[month].pay
        })).slice(-6) // Last 6 months
      };
    }
    
    return { data: [] };
  }

  // Achievement methods
  async getAchievementsByUserId(userId: number): Promise<Achievement[]> {
    return db.select().from(achievements).where(eq(achievements.user_id, userId));
  }

  async createAchievement(achievementData: Partial<Achievement>): Promise<Achievement> {
    const [achievement] = await db.insert(achievements).values({
      user_id: achievementData.user_id!,
      title: achievementData.title!,
      description: achievementData.description!,
      icon: achievementData.icon!,
      unlocked: achievementData.unlocked || 0,
      unlocked_at: achievementData.unlocked_at,
    }).returning();
    
    return achievement;
  }

  // Helper methods
  private async createDefaultAchievements(userId: number) {
    const defaultAchievements = [
      {
        title: "First Shift",
        description: "Completed your first shift",
        icon: "🏆",
        unlocked: 0
      },
      {
        title: "10 Hours Club",
        description: "Worked more than 10 hours",
        icon: "⏰",
        unlocked: 0
      },
      {
        title: "Big Earner",
        description: "Earned over $100 in a week",
        icon: "💰",
        unlocked: 0
      },
      {
        title: "Night Owl",
        description: "Completed 5 evening shifts",
        icon: "🦉",
        unlocked: 0
      },
      {
        title: "Weekend Warrior",
        description: "Worked 3 weekends in a row",
        icon: "🏅",
        unlocked: 0
      }
    ];
    
    for (const achievement of defaultAchievements) {
      await this.createAchievement({
        ...achievement,
        user_id: userId
      });
    }
  }
}

export const storage = new DatabaseStorage();

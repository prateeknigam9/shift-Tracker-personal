import { pgTable, text, serial, integer, numeric, timestamp, date, time } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  full_name: text("full_name").notNull(),
});

export const shifts = pgTable("shifts", {
  id: serial("id").primaryKey(),
  user_id: integer("user_id").notNull().references(() => users.id),
  date: date("date").notNull(),
  start_time: time("start_time").notNull(),
  end_time: time("end_time").notNull(),
  break_time: numeric("break_time").notNull(), // in hours
  notes: text("notes"),
  hourly_rate: numeric("hourly_rate").notNull(),
  total_pay: numeric("total_pay").notNull(),
});

export const achievements = pgTable("achievements", {
  id: serial("id").primaryKey(),
  user_id: integer("user_id").notNull().references(() => users.id),
  title: text("title").notNull(),
  description: text("description").notNull(),
  icon: text("icon").notNull(),
  unlocked: integer("unlocked").notNull().default(0),
  unlocked_at: timestamp("unlocked_at"),
});

// Relationships
export const usersRelations = relations(users, ({ many }) => ({
  shifts: many(shifts),
  achievements: many(achievements),
}));

export const shiftsRelations = relations(shifts, ({ one }) => ({
  user: one(users, {
    fields: [shifts.user_id],
    references: [users.id],
  }),
}));

export const achievementsRelations = relations(achievements, ({ one }) => ({
  user: one(users, {
    fields: [achievements.user_id],
    references: [users.id],
  }),
}));

// Schemas for validation/insertion
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  full_name: true,
});

export const insertShiftSchema = createInsertSchema(shifts).omit({
  id: true,
  user_id: true,
  total_pay: true,
});

export const insertAchievementSchema = createInsertSchema(achievements).omit({
  id: true,
  user_id: true,
  unlocked_at: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Shift = typeof shifts.$inferSelect;
export type InsertShift = z.infer<typeof insertShiftSchema>;
export type Achievement = typeof achievements.$inferSelect;
export type InsertAchievement = z.infer<typeof insertAchievementSchema>;
